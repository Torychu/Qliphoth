package Collection;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<>();
		
		list.add("유재석");
		list.add("ㄲㄲㄲ");
		list.add("지석진");
		list.add("ㄲㄲㄲ");
		list.add("김종국");
		list.add("ㄲㄲㄲ");
		list.add("송지효");
		list.add("ㄲㄲㄲ");
		list.add("하하");
		
		System.out.println(list);
		System.out.println("--------------------------");
		
		Iterator<String> it = list.iterator();
		System.out.println(it.next());
		System.out.println(it.next());
		System.out.println("--------------------------");
		
		it=list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		System.out.println("--------------------------");
		it = list.iterator();
		while(it.hasNext()) {
			String s = it.next();
			if(s.contains("ㄲㄲㄲ")) {
				it.remove();
			}
		}
		System.out.println(list);
	}

}
